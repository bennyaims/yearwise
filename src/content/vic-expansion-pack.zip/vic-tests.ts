import type { Lesson } from "@/lib/types";

// TEST GENERATOR — Vic: 4 tests per term per subject Y7-10, SAC-style Y11-12
export type TestConfig = {
  year: number;
  subject: string;
  term: 1 | 2 | 3 | 4;
  testNumber: number;
  lessonIds: string[]; // which lessons this test covers
};

export function generateVicTestSchedule(lessons: Lesson[]) {
  // Group by year+subject, sort by lesson order
  const groups = new Map<string, Lesson[]>();
  for (const l of lessons) {
    const key = `${l.year}:${l.subject}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(l);
  }
  const schedule: TestConfig[] = [];
  for (const [key, group] of groups) {
    const [yearStr, subject] = key.split(":");
    const year = Number(yearStr);
    const perTerm = year <= 10 ? 4 : 2;
    const chunkSize = Math.ceil(group.length / 4);
    for (let term = 1; term <= 4; term++) {
      const start = (term - 1) * chunkSize;
      const chunk = group.slice(start, start + chunkSize);
      if (chunk.length === 0) continue;
      // Create 2-4 tests per term depending on year
      const testsInTerm = perTerm === 4 ? Math.min(4, chunk.length) : perTerm;
      const perTest = Math.ceil(chunk.length / testsInTerm);
      for (let t = 0; t < testsInTerm; t++) {
        const testLessons = chunk.slice(t * perTest, (t + 1) * perTest);
        if (testLessons.length === 0) continue;
        schedule.push({
          year,
          subject,
          term: term as any,
          testNumber: t + 1,
          lessonIds: testLessons.map(l => l.id),
        });
      }
    }
  }
  return schedule;
}

// Example: build 16 tests per year per subject for Y7-10
// Implementation hook for src/lib/weekly-test.ts
export function buildVicTestsForYear(year: number, subject: string, lessons: Lesson[]) {
  const schedule = generateVicTestSchedule(lessons).filter(s => s.year === year && s.subject === subject);
  return schedule.map(s => ({
    id: `vic-test-y${s.year}-${s.subject}-t${s.term}-${s.testNumber}`,
    title: `Year ${s.year} ${subject} — Term ${s.term} Test ${s.testNumber}`,
    year: s.year,
    subject: s.subject,
    term: s.term,
    lessonsCovered: s.lessonIds,
    questionCount: 12, // 12 Qs per test (more than weekly)
    timeLimitMinutes: 30,
  }));
}
