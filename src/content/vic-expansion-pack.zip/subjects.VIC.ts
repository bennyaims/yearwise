import type { LanguageMeta, SubjectMeta, YearLevel } from "./types";

export const YEARS: YearLevel[] = [7, 8, 9, 10, 11, 12];

export const SUBJECTS: SubjectMeta[] = [
  {
    id: "math",
    name: "Mathematics",
    shortName: "Maths",
    description: "Vic F-10 v2.0 Number, Algebra, Measurement, Geometry, Statistics + VCE General / Methods / Specialist.",
    color: "#5b8fd4",
    icon: "∑",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "english",
    name: "English",
    shortName: "English",
    description: "Vic F-10 Reading, Writing, Literature + VCE English / Literature argument analysis & text response.",
    color: "#c47a8a",
    icon: "📖",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "science",
    name: "Science",
    shortName: "Science",
    description: "Biology, Chemistry, Physics, Psychology, Earth & Environmental — Vic F-10 + VCE Units 1-4 foundations.",
    color: "#4a9b72",
    icon: "🔬",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "chemistry",
    name: "Chemistry",
    shortName: "Chem",
    description: "VCE Chemistry Units 1-4: atomic structure, bonding, stoichiometry, organic, equilibrium.",
    color: "#8b7ec8",
    icon: "⚗️",
    years: [10, 11, 12],
  },
  {
    id: "history",
    name: "Humanities",
    shortName: "Humanities",
    description: "Vic F-10 History (First Nations deep history), Geography (liveability), Civics & Citizenship, Economics & Business — VCE prep.",
    color: "#c9a04a",
    icon: "🌏",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "music",
    name: "Music & Arts",
    shortName: "Arts",
    description: "Visual Arts, Media, Music, Drama, Visual Communication Design — Vic Arts curriculum.",
    color: "#c47aad",
    icon: "🎨",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "computerscience",
    name: "Computer Science & Technologies",
    shortName: "CS",
    description: "Vic Technologies: Digital Tech — Applied Computing, Algorithmics HESS + Design & Tech. Choose pathway each year.",
    color: "#5b9fd4",
    icon: "💻",
    years: [7, 8, 9, 10, 11, 12],
  },
  {
    id: "language",
    name: "Languages",
    shortName: "Language",
    description: "Vic Languages: choose one language Y7-12 until fluent. Exit B1+/B2-.",
    color: "#d48a5a",
    icon: "🌍",
    years: [7, 8, 9, 10, 11, 12],
  },
  // NEW — needed for Vic Health & PE requirement
  {
    id: "health_pe" as any,
    name: "Health & PE",
    shortName: "HPE",
    description: "Vic Health & Physical Education + VCE HHD & PE — health literacy, fitness, safety, relationships.",
    color: "#e07a5f",
    icon: "🏃",
    years: [7, 8, 9, 10, 11, 12],
  } as SubjectMeta,
];

export const LANGUAGES = [
  { id: "spanish", name: "Spanish", nativeName: "Español", flag: "🇪🇸", description: "Global language." },
  { id: "russian", name: "Russian", nativeName: "Русский", flag: "🇷🇺", description: "Cyrillic & literature." },
  { id: "chinese", name: "Chinese (Mandarin)", nativeName: "中文", flag: "🇨🇳", description: "Mandarin." },
  { id: "german", name: "German", nativeName: "Deutsch", flag: "🇩🇪", description: "Science & culture." },
  { id: "japanese", name: "Japanese", nativeName: "日本語", flag: "🇯🇵", description: "Japan." },
  { id: "khmer", name: "Khmer", nativeName: "ភាសាខ្មែរ", flag: "🇰🇭", description: "Cambodia." },
  { id: "italian", name: "Italian", nativeName: "Italiano", flag: "🇮🇹", description: "Romance language." },
] as LanguageMeta[];

export function getSubject(id: string) { return SUBJECTS.find(s => s.id === id); }
export function getLanguage(id: string) { return LANGUAGES.find(l => l.id === id); }
export function subjectsForYear(year: YearLevel) { return SUBJECTS.filter(s => s.years.includes(year)); }
