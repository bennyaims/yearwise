/**
 * Victorian Curriculum F-10 v2.0 + VCE Units 1-4 mapping for Yearwise
 * Source: VCAA planning guidelines + vic.gov.au VCE subject list 2025-26
 * Use this as the single source of truth for year/subject/lesson counts
 */
export const VIC_CURRICULUM = {
  // Years 7-10: 8 Learning Areas
  f10: {
    7: ["math", "english", "science", "humanities", "health_pe", "arts", "technologies", "language"],
    8: ["math", "english", "science", "humanities", "health_pe", "arts", "technologies", "language"],
    9: ["math", "english", "science", "humanities", "health_pe", "arts", "technologies", "language"],
    10: ["math", "english", "science", "humanities", "health_pe", "arts", "technologies", "language"],
  },
  // Year 10 also allows early VCE Units 1-2
  vcePathways: {
    english: ["English", "English Language", "Literature", "EAL"],
    math: ["Foundation Mathematics", "General Mathematics", "Mathematical Methods", "Specialist Mathematics"],
    science: ["Biology", "Chemistry", "Physics", "Psychology", "Environmental Science"],
    humanities: ["History", "Geography", "Legal Studies", "Business Management", "Economics", "Philosophy", "Politics"],
    technologies: ["Applied Computing", "Algorithmics HESS", "Product Design & Technology", "Systems Engineering", "Food Studies"],
    health_pe: ["Health & Human Development", "Physical Education", "Outdoor & Environmental Studies"],
    arts: ["Art Creative Practice", "Art Making & Exhibiting", "Media", "Visual Communication Design", "Music", "Drama"],
  }
} as const;

export const LESSON_TARGETS = {
  "7-10": { lessonsPerSubject: 40, testsPerTerm: 4, terms: 4 }, // 16 tests total
  "11": { lessonsPerSubject: 50, testsPerTerm: 2, terms: 4 }, // 8 SACs
  "12": { lessonsPerSubject: 60, testsPerTerm: 2.5, terms: 4 }, // 10 SACs
};

// What you currently have vs missing
export const GAP_ANALYSIS = {
  have: {
    math: "Y7 (in lessons.ts) + Y8, Y9, Y10-12 files — COMPLETE, just needs splitting",
    science: "cells-learn-path.ts only — needs 35+ more lessons",
    english: "MISSING — 0 lessons",
    history: "Have unfiltered Aus history but not Vic F-10 History/Geography/Civics/Economics",
    music: "Have Y7-12 music scaffold — needs linking to Arts",
    computerscience: "Have full pathway — maps to Technologies",
    language: "Have fluency pathway — COMPLETE",
  },
  missing: ["english", "humanities: geography, civics, economics", "health_pe", "arts: visual, media, drama, design", "vce specialised subjects"]
};
